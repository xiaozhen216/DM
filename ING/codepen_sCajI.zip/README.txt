A Pen created at CodePen.io. You can find this one at http://codepen.io/samthejarvis/pen/sCajI.

 An experiment with natural animation. Resizable via font-size!